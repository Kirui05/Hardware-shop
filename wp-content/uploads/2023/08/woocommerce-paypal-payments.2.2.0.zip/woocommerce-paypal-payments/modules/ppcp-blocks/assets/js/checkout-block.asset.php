<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => 'bad5ae0592b1833a7477');
