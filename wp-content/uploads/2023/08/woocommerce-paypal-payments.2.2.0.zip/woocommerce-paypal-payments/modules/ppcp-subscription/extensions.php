<?php
/**
 * The extensions.
 *
 * @package WooCommerce\PayPalCommerce\Subscription
 */

declare(strict_types=1);

return array();
